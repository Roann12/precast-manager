# File overview: Application module logic for app/database.py.
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from .core.config import settings

engine = create_engine(settings.sqlalchemy_database_uri, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True)

Base = declarative_base()


# Handles get db flow.
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

