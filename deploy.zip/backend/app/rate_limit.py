# File overview: Application module logic for app/rate_limit.py.
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
